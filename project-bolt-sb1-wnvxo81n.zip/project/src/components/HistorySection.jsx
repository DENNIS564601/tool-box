import React from 'react';

export const HistorySection = ({ region }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <h3 className="text-xl font-bold text-gray-800 mb-4">Historical Background</h3>
      <div className="space-y-4">
        <div>
          <h4 className="font-semibold text-gray-700">Origin</h4>
          <p className="text-gray-600">{region.origin}</p>
        </div>
        <div>
          <h4 className="font-semibold text-gray-700">Key Influences</h4>
          <p className="text-gray-600">{region.influence}</p>
        </div>
        <div>
          <h4 className="font-semibold text-gray-700">Signature Style</h4>
          <p className="text-gray-600">{region.keyFeature}</p>
        </div>
        <div>
          <h4 className="font-semibold text-gray-700">Cultural Impact</h4>
          <p className="text-gray-600">{region.culturalImpact}</p>
        </div>
      </div>
    </div>
  );
};