import React from 'react';

export const Resources = () => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-semibold text-gray-800 mb-4">Resources</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-4 bg-gray-50 rounded-lg">
          <h3 className="font-semibold text-gray-700 mb-2">Templates</h3>
          <ul className="list-disc pl-5 text-gray-600">
            <li>eBook Outline Template</li>
            <li>Marketing Plan Template</li>
            <li>Sales Funnel Template</li>
          </ul>
        </div>
        <div className="p-4 bg-gray-50 rounded-lg">
          <h3 className="font-semibold text-gray-700 mb-2">Tools</h3>
          <ul className="list-disc pl-5 text-gray-600">
            <li>Keyword Research Tool</li>
            <li>Content Generator</li>
            <li>Analytics Dashboard</li>
          </ul>
        </div>
      </div>
    </div>
  );
};