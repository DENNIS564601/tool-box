import React from 'react';
import { StarIcon } from '@heroicons/react/20/solid';
import { formatPrice, formatRating } from '../../utils/formatters';

export const DishCard = ({ dish }) => {
  return (
    <div className="bg-gray-50 rounded-lg overflow-hidden shadow-md">
      <img 
        src={dish.image} 
        alt={dish.name}
        className="w-full h-48 object-cover"
      />
      <div className="p-4">
        <h3 className="text-xl font-semibold text-gray-800">{dish.name}</h3>
        <p className="text-gray-600 text-sm mt-1">{dish.description}</p>
        <div className="flex justify-between items-center mt-3">
          <span className="text-lg font-bold text-gray-800">
            {formatPrice(dish.price)}
          </span>
          <div className="flex items-center">
            <StarIcon className="h-5 w-5 text-yellow-400" />
            <span className="ml-1 text-gray-600">{formatRating(dish.rating)}</span>
          </div>
        </div>
      </div>
    </div>
  );
};