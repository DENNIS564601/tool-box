import React from 'react';

export const RecipeCard = ({ recipe }) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <h3 className="text-2xl font-bold text-gray-800 mb-4">{recipe.name}</h3>
      
      <div className="grid grid-cols-3 gap-4 mb-6 text-sm">
        <div className="text-center p-2 bg-gray-50 rounded">
          <p className="font-semibold">Difficulty</p>
          <p className="text-gray-600">{recipe.difficulty}</p>
        </div>
        <div className="text-center p-2 bg-gray-50 rounded">
          <p className="font-semibold">Prep Time</p>
          <p className="text-gray-600">{recipe.prepTime}</p>
        </div>
        <div className="text-center p-2 bg-gray-50 rounded">
          <p className="font-semibold">Cook Time</p>
          <p className="text-gray-600">{recipe.cookTime}</p>
        </div>
      </div>

      <div className="mb-6">
        <h4 className="font-semibold text-lg mb-2">Ingredients</h4>
        <ul className="list-disc pl-5 space-y-1">
          {recipe.ingredients.map((ingredient, index) => (
            <li key={index} className="text-gray-600">{ingredient}</li>
          ))}
        </ul>
      </div>

      <div className="mb-6">
        <h4 className="font-semibold text-lg mb-2">Instructions</h4>
        <ol className="list-decimal pl-5 space-y-2">
          {recipe.instructions.map((step, index) => (
            <li key={index} className="text-gray-600">{step}</li>
          ))}
        </ol>
      </div>

      <div>
        <h4 className="font-semibold text-lg mb-2">Pro Tips</h4>
        <ul className="list-disc pl-5 space-y-1">
          {recipe.tips.map((tip, index) => (
            <li key={index} className="text-gray-600">{tip}</li>
          ))}
        </ul>
      </div>
    </div>
  );
};