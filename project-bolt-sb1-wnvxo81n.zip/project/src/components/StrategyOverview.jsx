import React from 'react';

export const StrategyOverview = () => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <h2 className="text-2xl font-semibold text-gray-800 mb-4">Strategy Overview</h2>
      <div className="space-y-4">
        <div>
          <h3 className="font-semibold text-gray-700">1. Content Creation</h3>
          <p className="text-gray-600">Advanced research and niche domination strategies</p>
        </div>
        <div>
          <h3 className="font-semibold text-gray-700">2. Marketing Excellence</h3>
          <p className="text-gray-600">Multi-channel marketing and distribution strategies</p>
        </div>
        <div>
          <h3 className="font-semibold text-gray-700">3. Revenue Maximization</h3>
          <p className="text-gray-600">Upsells, cross-sells, and affiliate marketing integration</p>
        </div>
      </div>
    </div>
  );
};