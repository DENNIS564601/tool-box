import React from 'react';

export const Header = () => {
  return (
    <header className="bg-gradient-to-r from-red-700 to-red-900 text-white py-8 mb-8">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold text-center">
          BBQ By Sam
        </h1>
        <p className="text-center mt-2 text-gray-200">
          Exploring America's Rich BBQ Heritage - History, Styles, and Signature Dishes
        </p>
      </div>
    </header>
  );
};