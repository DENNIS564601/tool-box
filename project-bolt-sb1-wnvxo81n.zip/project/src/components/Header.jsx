import React from 'react';

export const Header = () => {
  return (
    <header className="text-center mb-8">
      <h1 className="text-4xl font-bold text-gray-800 mb-2">eBook Strategy Tool</h1>
      <p className="text-gray-600">Your all-in-one solution for eBook creation and marketing</p>
    </header>
  );
};