import React from 'react';
import { RestaurantCard } from '../restaurants/RestaurantCard';
import { HistorySection } from '../history/HistorySection';
import { RecipeCard } from '../recipes/RecipeCard';
import { bbqRecipes } from '../../data/bbqRecipes';

export const SearchResults = ({ 
  searchTerm, 
  filteredRestaurants, 
  filteredHistory 
}) => {
  const filteredRecipes = searchTerm ? 
    Object.values(bbqRecipes)
      .flatMap(region => Object.values(region))
      .filter(recipe => 
        recipe.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        recipe.ingredients.some(i => i.toLowerCase().includes(searchTerm.toLowerCase()))
      )
    : [];

  if (filteredRestaurants.length === 0 && !filteredHistory.length && filteredRecipes.length === 0 && searchTerm) {
    return (
      <div className="text-center text-gray-600">
        No results found for "{searchTerm}"
      </div>
    );
  }

  return (
    <div>
      {filteredHistory.map(history => (
        <HistorySection key={history.region} region={history} />
      ))}
      {filteredRecipes.map((recipe, index) => (
        <RecipeCard key={index} recipe={recipe} />
      ))}
      {filteredRestaurants.map(restaurant => (
        <RestaurantCard key={restaurant.id} restaurant={restaurant} />
      ))}
    </div>
  );
};