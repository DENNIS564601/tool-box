import React from 'react';
import { DishCard } from './DishCard';

export const RestaurantCard = ({ restaurant }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
      <div className="mb-4">
        <h2 className="text-2xl font-bold text-gray-800">{restaurant.name}</h2>
        <p className="text-gray-600">{restaurant.location}</p>
        <p className="text-sm text-gray-500">Signature Dish: {restaurant.signature}</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {restaurant.dishes.map((dish) => (
          <DishCard key={dish.id} dish={dish} />
        ))}
      </div>
    </div>
  );
};