import React from 'react';

export const QuickStartGuide = () => {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <h2 className="text-2xl font-semibold text-gray-800 mb-4">Quick Start Guide</h2>
      <div className="space-y-4">
        <div>
          <h3 className="font-semibold text-gray-700">Step 1: Research</h3>
          <p className="text-gray-600">Use keyword research tools to identify profitable niches</p>
        </div>
        <div>
          <h3 className="font-semibold text-gray-700">Step 2: Create</h3>
          <p className="text-gray-600">Develop high-quality content using AI tools and templates</p>
        </div>
        <div>
          <h3 className="font-semibold text-gray-700">Step 3: Market</h3>
          <p className="text-gray-600">Implement omni-channel marketing strategies</p>
        </div>
        <div>
          <h3 className="font-semibold text-gray-700">Step 4: Scale</h3>
          <p className="text-gray-600">Optimize and expand your eBook business</p>
        </div>
      </div>
    </div>
  );
};