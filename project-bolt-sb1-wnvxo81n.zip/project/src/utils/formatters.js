export const formatPrice = (price) => {
  return price.startsWith('$') ? price : `$${price}`;
};

export const formatRating = (rating) => {
  return rating.toFixed(1);
};