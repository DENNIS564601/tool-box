export const filterHistoryBySearchTerm = (history, searchTerm) => {
  if (!searchTerm) return [];
  
  const searchLower = searchTerm.toLowerCase();
  return Object.entries(history)
    .filter(([region, data]) => 
      region.includes(searchLower) ||
      data.origin.toLowerCase().includes(searchLower) ||
      data.influence.toLowerCase().includes(searchLower) ||
      data.keyFeature.toLowerCase().includes(searchLower) ||
      data.culturalImpact.toLowerCase().includes(searchLower)
    )
    .map(([region, data]) => ({
      ...data,
      region
    }));
};