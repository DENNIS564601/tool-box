export const bbqRecipes = {
  texas: {
    brisket: {
      name: "Texas-Style Smoked Brisket",
      difficulty: "Advanced",
      prepTime: "1 hour",
      cookTime: "12-18 hours",
      ingredients: [
        "12-14 lb whole beef brisket, untrimmed",
        "1/4 cup coarse black pepper",
        "1/4 cup kosher salt",
        "Oak or hickory wood chunks"
      ],
      instructions: [
        "Trim the fat cap to 1/4 inch thickness",
        "Mix salt and pepper to create the rub",
        "Apply rub generously to all sides",
        "Preheat smoker to 250°F using oak wood",
        "Smoke fat side up until internal temperature reaches 165°F (about 6-8 hours)",
        "Wrap in butcher paper and continue smoking until internal temperature reaches 203°F (about 6-8 more hours)",
        "Rest wrapped for 1-2 hours before slicing"
      ],
      tips: [
        "Choose Prime or Choice grade brisket",
        "Look for good marbling and a thick flat",
        "Maintain consistent temperature throughout the cook"
      ]
    }
  },
  kansasCity: {
    burntEnds: {
      name: "Kansas City Burnt Ends",
      difficulty: "Intermediate",
      prepTime: "30 minutes",
      cookTime: "6-8 hours",
      ingredients: [
        "6-8 lb brisket point",
        "1/4 cup brown sugar",
        "2 tbsp paprika",
        "2 tbsp black pepper",
        "2 tbsp kosher salt",
        "1 cup Kansas City-style BBQ sauce"
      ],
      instructions: [
        "Separate the point from the flat",
        "Mix dry ingredients for the rub",
        "Apply rub liberally to the point",
        "Smoke at 250°F until internal temperature reaches 165°F",
        "Cube the meat into 1-inch pieces",
        "Toss with BBQ sauce and return to smoker",
        "Cook until cubes are caramelized and tender (about 1-2 more hours)"
      ],
      tips: [
        "Use the point cut for the best results",
        "Don't rush the final glazing step",
        "Look for bark formation before cubing"
      ]
    }
  }
};