export const bbqHistory = {
  texas: {
    origin: "19th century European immigrants, particularly German and Czech",
    influence: "Cattle ranching history and European smoking traditions",
    keyFeature: "Focus on beef, particularly brisket, with minimal seasoning",
    culturalImpact: "Developed 'low and slow' smoking method for tough cuts"
  },
  kansasCity: {
    origin: "Early 20th century, started by Henry Perry",
    influence: "Major meatpacking and railroad hub location",
    keyFeature: "Variety of meats with thick, sweet sauces",
    culturalImpact: "Melting pot of various BBQ styles due to central location"
  },
  memphis: {
    origin: "African American community in Mississippi Delta",
    influence: "Blues culture and African smoking traditions",
    keyFeature: "Pork-focused, especially ribs with dry rub or wet sauce",
    culturalImpact: "Strong connection to music scene and community gatherings"
  },
  carolina: {
    origin: "One of the oldest US BBQ traditions",
    influence: "Native American methods and European colonial practices",
    keyFeature: "Whole hog (East) and pork shoulder (West) with vinegar-based sauces",
    culturalImpact: "Central to community events and family gatherings"
  },
  alabama: {
    origin: "1920s, white sauce created by Bob Gibson",
    influence: "Agricultural history and family-owned establishments",
    keyFeature: "Unique white sauce, especially with chicken",
    culturalImpact: "Distinctive regional identity through sauce innovation"
  },
  stLouis: {
    origin: "19th century meatpacking industry",
    influence: "Mississippi River trade and immigrant populations",
    keyFeature: "Distinctive rib cut and sweet-tangy sauce",
    culturalImpact: "Blend of Southern and Midwestern BBQ traditions"
  }
};