export const bbqRestaurants = [
  {
    id: 1,
    name: "Franklin Barbecue",
    location: "Austin, TX",
    signature: "Brisket",
    dishes: [
      {
        id: 1,
        name: "Brisket",
        description: "Slow-smoked for 12-18 hours with post oak wood",
        price: "$25/lb",
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1623653387945-2fd25214f8fc?auto=format&fit=crop&w=800"
      },
      {
        id: 2,
        name: "Pulled Pork",
        description: "Tender, hand-pulled pork shoulder",
        price: "$20/lb",
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1602088113235-229c19758e9f?auto=format&fit=crop&w=800"
      }
    ]
  },
  {
    id: 2,
    name: "Joe's Kansas City Bar-B-Que",
    location: "Kansas City, KS",
    signature: "Z-Man Sandwich",
    dishes: [
      {
        id: 3,
        name: "Z-Man Sandwich",
        description: "Brisket, smoked provolone, onion rings on kaiser roll",
        price: "$8.99",
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1614398751058-eb2e0bf63e53?auto=format&fit=crop&w=800"
      },
      {
        id: 4,
        name: "Burnt Ends",
        description: "Flavorful cubes of brisket point",
        price: "$22/lb",
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1529193591184-b1d58069ecdd?auto=format&fit=crop&w=800"
      }
    ]
  },
  {
    id: 3,
    name: "Pappy's Smokehouse",
    location: "St. Louis, MO",
    signature: "St. Louis Style Ribs",
    dishes: [
      {
        id: 5,
        name: "St. Louis Style Ribs",
        description: "Memphis-style dry rub, slow-smoked ribs",
        price: "$24/rack",
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800"
      },
      {
        id: 6,
        name: "Smoked Turkey",
        description: "Juicy apple-brined turkey breast",
        price: "$18/lb",
        rating: 4.6,
        image: "https://images.unsplash.com/photo-1574672280600-4accfa5b6f98?auto=format&fit=crop&w=800"
      }
    ]
  }
];