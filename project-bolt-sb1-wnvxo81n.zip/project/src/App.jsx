import React from 'react';
import { Header } from './components/Header';
import { StrategyOverview } from './components/StrategyOverview';
import { QuickStartGuide } from './components/QuickStartGuide';
import { Resources } from './components/Resources';

function App() {
  return (
    <div className="bg-gray-100 min-h-screen">
      <div className="container mx-auto px-4 py-8">
        <Header />
        <main className="max-w-4xl mx-auto">
          <StrategyOverview />
          <QuickStartGuide />
          <Resources />
        </main>
      </div>
    </div>
  );
}

export default App;