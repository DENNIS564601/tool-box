import { useState, useMemo } from 'react';

export const useSearch = (data, searchFields) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredResults = useMemo(() => {
    if (!searchTerm) return data;
    
    const searchLower = searchTerm.toLowerCase();
    return data.filter(item => 
      searchFields.some(field => {
        const value = field.split('.').reduce((obj, key) => obj?.[key], item);
        if (Array.isArray(value)) {
          return value.some(v => 
            Object.values(v).some(val => 
              String(val).toLowerCase().includes(searchLower)
            )
          );
        }
        return String(value).toLowerCase().includes(searchLower);
      })
    );
  }, [data, searchTerm, searchFields]);

  return { searchTerm, setSearchTerm, filteredResults };
};